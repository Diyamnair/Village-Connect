# Parkinson's Disease Screening — ML Research Starter

A tabular ML starter for handwriting-derived or clinical feature datasets. It deliberately does not invent the algorithm, dataset, or accuracy from the project description.

## Expected input
A CSV with numeric feature columns and a target column. Configure the target column with `--target`. Do not include names, contact details, or other patient identifiers.

## Run
```bash
pip install -r requirements.txt
python train_baseline.py --csv data/your_authorised_dataset.csv --target diagnosis
```

The script uses a stratified train/test split and reports accuracy, precision, recall, F1, and a confusion matrix. It is a baseline scaffold, not a clinical model.

## Important
This is for educational research only and cannot diagnose Parkinson's disease. Use an authorised dataset, document its provenance and split strategy, prevent data leakage, and report actual results. Replace this baseline with the algorithms actually used in your project if they differ.
