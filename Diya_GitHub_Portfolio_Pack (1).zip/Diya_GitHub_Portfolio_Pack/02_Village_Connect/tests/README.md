# Tests
Add pytest tests for validation, CRUD routes, error responses, and database behaviour before treating this starter as complete.
