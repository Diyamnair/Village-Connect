PROJECT_NAME = 'Village Connect'

from flask import Flask, jsonify, request
import sqlite3
from pathlib import Path

APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "app.db"
app = Flask(__name__)

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT DEFAULT '',
            details TEXT DEFAULT '',
            status TEXT DEFAULT 'active'
        )""")

@app.get("/")
def home():
    return jsonify({"project": PROJECT_NAME, "message": "Reference API is running", "routes": ["/api/records"]})

@app.get("/api/records")
def list_records():
    with connect() as con:
        rows = con.execute("SELECT * FROM records ORDER BY id DESC").fetchall()
    return jsonify([dict(r) for r in rows])

@app.post("/api/records")
def create_record():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    with connect() as con:
        cur = con.execute(
            "INSERT INTO records(name, category, details, status) VALUES (?, ?, ?, ?)",
            (name, data.get("category", ""), data.get("details", ""), data.get("status", "active"))
        )
        record_id = cur.lastrowid
    return jsonify({"id": record_id, "name": name}), 201

@app.get("/api/records/<int:record_id>")
def get_record(record_id):
    with connect() as con:
        row = con.execute("SELECT * FROM records WHERE id = ?", (record_id,)).fetchone()
    if not row:
        return jsonify({"error": "record not found"}), 404
    return jsonify(dict(row))

@app.patch("/api/records/<int:record_id>")
def update_record(record_id):
    data = request.get_json(silent=True) or {}
    allowed = {"name", "category", "details", "status"}
    fields = {k: v for k, v in data.items() if k in allowed}
    if not fields:
        return jsonify({"error": "no valid fields supplied"}), 400
    with connect() as con:
        row = con.execute("SELECT id FROM records WHERE id = ?", (record_id,)).fetchone()
        if not row:
            return jsonify({"error": "record not found"}), 404
        assignments = ", ".join(f"{k} = ?" for k in fields)
        con.execute(f"UPDATE records SET {assignments} WHERE id = ?", (*fields.values(), record_id))
    return jsonify({"updated": record_id})

@app.delete("/api/records/<int:record_id>")
def delete_record(record_id):
    with connect() as con:
        cur = con.execute("DELETE FROM records WHERE id = ?", (record_id,))
    if cur.rowcount == 0:
        return jsonify({"error": "record not found"}), 404
    return jsonify({"deleted": record_id})

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
