# HR Policy & Employee Benefits Copilot

A small Flask reference application that indexes policy text files, retrieves relevant passages using TF-IDF similarity, and returns a grounded answer with source snippets. An optional hosted LLM integration can be added after configuring a provider.

## Features
- Flask REST API
- Document ingestion from `knowledge_base/` (`.txt` and `.md`)
- TF-IDF retrieval with cosine similarity
- Grounded response assembled from retrieved passages
- Source snippets returned as JSON
- Simple browser UI

## Run
```bash
python -m venv .venv
# activate the environment
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:5001`.

## API
- `GET /api/health`
- `POST /api/ask` with `{"question":"How many annual leave days are available?"}`
- `POST /api/reindex`

## Important
This is a retrieval-focused demo, not an actual HR policy system. Replace sample policies with documents you are authorised to use. Do not use it to make employment decisions. Add authentication, access control, audit logging, privacy controls, and a verified LLM provider integration before any real deployment.
