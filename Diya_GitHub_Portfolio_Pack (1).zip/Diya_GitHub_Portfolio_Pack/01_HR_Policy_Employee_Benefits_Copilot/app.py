from pathlib import Path
from flask import Flask, jsonify, request, render_template_string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)
KB_DIR = Path(__file__).parent / "knowledge_base"
documents = []
vectorizer = None
matrix = None

PAGE = """
<!doctype html><html><head><title>HR Policy Copilot Demo</title>
<style>body{font:16px Arial;max-width:850px;margin:40px auto;padding:0 16px}
textarea{width:100%;height:90px}button{padding:10px 18px;margin-top:10px}
pre{white-space:pre-wrap;background:#f4f4f4;padding:14px}</style></head>
<body><h1>HR Policy & Benefits Copilot</h1>
<p>Demo only — answers are based on the sample policy files.</p>
<textarea id="q" placeholder="Ask a policy question..."></textarea><br>
<button onclick="ask()">Ask</button><pre id="out"></pre>
<script>
async function ask(){const q=document.getElementById('q').value;
const r=await fetch('/api/ask',{method:'POST',headers:{'Content-Type':'application/json'},
body:JSON.stringify({question:q})});document.getElementById('out').textContent=JSON.stringify(await r.json(),null,2);}
</script></body></html>
"""

def reindex():
    global documents, vectorizer, matrix
    documents = []
    for path in sorted(KB_DIR.glob("*")):
        if path.suffix.lower() in {".txt", ".md"}:
            text = path.read_text(encoding="utf-8", errors="ignore").strip()
            if text:
                documents.append({"source": path.name, "text": text})
    if documents:
        vectorizer = TfidfVectorizer(stop_words="english")
        matrix = vectorizer.fit_transform([d["text"] for d in documents])
    else:
        vectorizer, matrix = None, None

@app.get("/")
def home():
    return render_template_string(PAGE)

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "documents_indexed": len(documents)})

@app.post("/api/reindex")
def reindex_route():
    reindex()
    return jsonify({"status": "indexed", "documents": len(documents)})

@app.post("/api/ask")
def ask():
    payload = request.get_json(silent=True) or {}
    question = (payload.get("question") or "").strip()
    if not question:
        return jsonify({"error": "question is required"}), 400
    if not documents or vectorizer is None:
        return jsonify({"answer": "No policy documents are indexed.", "sources": []}), 503
    q_vec = vectorizer.transform([question])
    scores = cosine_similarity(q_vec, matrix).ravel()
    ranked = scores.argsort()[::-1][:2]
    sources = [{"source": documents[i]["source"], "score": round(float(scores[i]), 4),
                "snippet": documents[i]["text"][:700]} for i in ranked if scores[i] > 0]
    if not sources:
        answer = ("I could not find relevant information in the indexed policy documents. "
                  "Please contact the official HR team.")
    else:
        answer = ("Based on the retrieved sample policy text: " +
                  " ".join(s["snippet"] for s in sources) +
                  " Please confirm personal eligibility with HR.")
    return jsonify({"answer": answer, "sources": sources, "mode": "retrieval-grounded-demo"})

if __name__ == "__main__":
    reindex()
    app.run(host="127.0.0.1", port=5001, debug=True)
