# Breast Cancer Image Analysis — Research Prototype

Research-oriented starter based on the described project: contrast-enhanced spectral mammography (CESM), preprocessing, segmentation, feature learning, and classification.

## Reported project direction
- Dataset described: CDD-CESM
- Image processing described: background/pectoral-region handling, CLAHE, normalization, resizing
- Architecture described: U-Net++ segmentation, Swin Transformer feature extraction, EfficientNetV2-S classification
- Tools described: Python, PyTorch, OpenCV

## Included code
`preprocess.py` provides a safe, generic image preprocessing utility for a local image. It does **not** reproduce the full research architecture or provide a cancer prediction.

## Run
```bash
pip install -r requirements.txt
python preprocess.py --input path/to/image.png --output processed.png
```

## Research and safety note
This is not a diagnostic tool and must not be used for clinical decisions. No patient images or medical data are included. Obtain the dataset from its authorised source and follow its licence and ethics conditions. Do not publish patient-identifiable data. Add the actual model training and evaluation only from your verified project code. Do not claim accuracy unless you can reproduce it on a documented independent test set.
