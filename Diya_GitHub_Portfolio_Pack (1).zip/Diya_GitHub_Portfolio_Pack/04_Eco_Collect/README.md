# Eco Collect — Waste Networking Platform

A backend starter for recording waste collection requests and tracking their status.

## Technology note
Java/Spring Boot and MySQL were listed in the project description; this runnable reference uses Flask and SQLite for easy local demonstration.

## Run locally
```bash
python -m venv .venv
# activate the environment
pip install -r requirements.txt
python app.py
```
The API starts at `http://127.0.0.1:5000`.

## Example
```bash
curl -X POST http://127.0.0.1:5000/api/records \
  -H "Content-Type: application/json" \
  -d '{"name":"Example record","category":"waste collection requests and recycling coordination","details":"Demo entry"}'
```

## Scope and limitations
This is not the original Spring Boot code. Use it as a behaviour prototype, or replace it with your own Spring Boot implementation before presenting it as a Java project.

This is a reference implementation created from the project summary, not a claim that it reproduces your original source code. Replace demo functionality with your verified implementation and update this README before publishing.
