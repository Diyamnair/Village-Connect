# Facial Emotion Detection — Computer Vision Demo

This starter demonstrates webcam/video frame capture and face-region detection with OpenCV. It does not infer emotions by itself because the exact classifier used in the original project was not specified.

## Run
```bash
pip install -r requirements.txt
python detect_faces.py
```
Press `q` to quit.

## Add your actual emotion model
Replace the TODO section in `detect_faces.py` with the classifier you trained or used, and document:
- model source and licence
- emotion labels
- training/evaluation dataset
- test split and metrics

## Responsible-use note
Facial emotion inference is uncertain and can be biased across people and contexts. Do not use this demo for hiring, education, policing, medical, or other consequential decisions. Obtain informed consent before collecting or processing faces.
