# Real-Time Pipeline Monitoring Dashboard

A small API that accepts sensor readings and exposes recent readings for a dashboard.

## Technology note
Python, Flask, REST API, SQLite; MQTT adapter is documented as a next integration step.

## Run locally
```bash
python -m venv .venv
# activate the environment
pip install -r requirements.txt
python app.py
```
The API starts at `http://127.0.0.1:5000`.

## Example
```bash
curl -X POST http://127.0.0.1:5000/api/records \
  -H "Content-Type: application/json" \
  -d '{"name":"Example record","category":"temperature, pressure and gas sensor readings","details":"Demo entry"}'
```

## Scope and limitations
This demo accepts readings through HTTP. It does not connect to physical sensors or an MQTT broker until you add and test that integration.

This is a reference implementation created from the project summary, not a claim that it reproduces your original source code. Replace demo functionality with your verified implementation and update this README before publishing.
